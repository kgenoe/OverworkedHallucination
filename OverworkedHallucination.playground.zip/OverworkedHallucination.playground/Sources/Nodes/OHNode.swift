import Foundation
import SpriteKit

class OHNode: SKSpriteNode {
    
    func collisionWithCharacter(_ character: SKSpriteNode) {
        
    }
    
    func checkForRemoval(boundary: CGFloat){
        if self.position.x+self.size.width < boundary{
            self.removeFromParent()
        }
    }
}
