import SpriteKit
import UIKit

class OHCoin: OHNode{
    
    var gravity: CGFloat = -1.0
    
    var row: Row
    
    init(text: String, speed: CGFloat, row: Row){
        
        self.row = row
        
        // check the size that the text will take up
        let textNode = SKLabelNode(text: text)
        textNode.fontColor = UIColor.white
        textNode.fontName = "SFMono-Regular"
        textNode.fontSize = 20.0
        let size = CGSize(width: 35,
                          height: 25)
        textNode.position = CGPoint(x: 2, y: -8)
        
        // call super
        super.init(texture: nil, color: .clear, size: size)
        
        self.name = "Coin"
        

        // add child texture node
        addChild(textNode)
        
        // add physics body
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        self.physicsBody?.isDynamic = false
        self.physicsBody?.affectedByGravity = false
        self.physicsBody?.allowsRotation = false
        self.physicsBody?.collisionBitMask = 0
        self.physicsBody?.categoryBitMask = platformCategory
        self.physicsBody?.contactTestBitMask = characterCategory
        
        // add action
        let moveDuration = 17-speed
        let moveAction = SKAction.moveBy(x: -3000, y: 0, duration: TimeInterval(moveDuration))
        self.run(moveAction)
        
        let rotate1 = SKAction.scaleX(to: 1.0, duration: 0.7)
        let rotate2 = SKAction.scaleX(to: -1.0, duration: 0.7)
        let rotatePause = SKAction.wait(forDuration: 1.0)
        let rotateSequence = SKAction.sequence([rotate2, rotate1, rotatePause])
        
        self.run(SKAction.repeatForever(rotateSequence))
    
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func checkForRemoval(boundary: CGFloat) {
        if self.frame.maxX < boundary {
            self.removeFromParent()
        }
    }
    
    func collisionWith(player: OHCharacter){
        self.removeFromParent()
    }
}

