import SpriteKit

class OHCharacter: SKSpriteNode {
    
    var maxJumps: Int!
    var availableJumps: Int!
    
    var gravity: CGFloat = -1
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.zPosition = 10
        startRunningAnimation()
    }

    func startRunningAnimation(){
        let girlWalking1 = SKTexture(imageNamed: "Girl1")
        let girlWalking2 = SKTexture(imageNamed: "Girl2")
        let walkFrames = [girlWalking1, girlWalking2]
        let animateWalk = SKAction.animate(with: walkFrames, timePerFrame: 0.12, resize: false, restore: true)
        let repeatWalk = SKAction.repeatForever(animateWalk)
        self.run(repeatWalk, withKey: runKey)
    }
    
    func attachPhysicsBody(){
        let girlWalking2 = SKTexture(imageNamed: "Girl2")
        self.physicsBody = SKPhysicsBody(texture: girlWalking2, size: size)
        self.physicsBody?.allowsRotation = false
        self.physicsBody?.usesPreciseCollisionDetection = true
        self.physicsBody?.collisionBitMask = boundaryCategory
        self.physicsBody?.categoryBitMask = characterCategory
        self.physicsBody?.contactTestBitMask = platformCategory | boundaryCategory | coinCategory
    }
    
    func isOver(){
        self.removeAllActions()
        let girlEnd = SKTexture(imageNamed: "GirlEnd")
        self.texture = girlEnd
        self.physicsBody = nil
    }
    
    
    func gravityFlipped(gravity: CGFloat){
        self.gravity = gravity
        self.removeAction(forKey: runKey)

        
        let girlWalking1: SKTexture
        let girlWalking2: SKTexture
        if gravity < 0{
            girlWalking1 = SKTexture(imageNamed: "Girl1")
            girlWalking2 = SKTexture(imageNamed: "Girl2")
        }
        else{
            girlWalking1 = SKTexture(imageNamed: "Girl1Upsidedown")
            girlWalking2 = SKTexture(imageNamed: "Girl2Upsidedown")
        }
        let walkFrames = [girlWalking1, girlWalking2]
        let animateWalk = SKAction.animate(with: walkFrames, timePerFrame: 0.12, resize: false, restore: true)
        let repeatWalk = SKAction.repeatForever(animateWalk)
        self.run(repeatWalk, withKey: runKey)
    }
}

