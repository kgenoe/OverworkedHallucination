import SpriteKit
import UIKit

class OHPlatform: OHNode{
    
    var gravity: CGFloat = -1.0
    
    var row: Row
    
    init(text: String, speed: CGFloat, row: Row){
        
        self.row = row
        
        // check the size that the text will take up
        let textNode = SKLabelNode(text: text)
        textNode.fontColor = UIColor.white
        textNode.fontName = "SFMono-Regular"
        textNode.fontSize = 20.0
        let size = CGSize(width: textNode.frame.width+30,
                          height: 30)
        
        let attributedTextNode = AttributedLabelNode(size: size)
        attributedTextNode.position = CGPoint(x: 15, y: 0)

        let backgroundColor = UIColor(colorLiteralRed: 71/255.0, green: 82/255.0, blue: 95/255.0, alpha: 1.0)
        attributedTextNode.color = backgroundColor
        
        let attributedText = ColorParser().parse(text)
        attributedTextNode.attributedString = attributedText
      
        // call super
        super.init(texture: nil, color: backgroundColor, size: size)
        self.zPosition = 2.0
        
        self.name = "Platform"
        
        // add child texture node
        addChild(attributedTextNode)
        
        // add physics body
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        self.physicsBody?.isDynamic = false
        self.physicsBody?.affectedByGravity = false
        self.physicsBody?.allowsRotation = false
        self.physicsBody?.collisionBitMask = 0
        self.physicsBody?.categoryBitMask = platformCategory
        self.physicsBody?.contactTestBitMask = characterCategory
        
        // add action
        let moveDuration = 17-speed
        let moveAction = SKAction.moveBy(x: -3000, y: 0, duration: TimeInterval(moveDuration))
        self.run(moveAction)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func gravityFlipped(to gravity: CGFloat){
        self.gravity = gravity
    }
    
    func collisionWith(player: OHCharacter){
        if player.physicsBody!.velocity.dy < 0.0 && self.gravity < 0{

            let distance = player.frame.minY - frame.maxY
            if -10 < distance && distance < 10 {
                //if player ontop of platform and gravity is pulling down
                player.physicsBody!.affectedByGravity = false
                player.physicsBody!.velocity = CGVector.zero
                player.physicsBody = nil
                player.position = CGPoint(x: player.position.x, y: frame.maxY+(player.size.height/2))
                player.attachPhysicsBody()
                player.availableJumps = player.maxJumps
            }
        }

        if player.physicsBody!.velocity.dy > 0.0 && self.gravity > 0 {

            let distance = player.frame.maxY - frame.minY
            if -10 < distance && distance < 10 {
                // if player is under platform and gravity is pulling up
                player.physicsBody!.affectedByGravity = false
                player.physicsBody!.velocity = CGVector.zero
                player.physicsBody = nil
                player.position = CGPoint(x: player.position.x, y: frame.minY-(player.size.height/2)+1)
                player.attachPhysicsBody()
                player.availableJumps = player.maxJumps

            }
        }
    }
}


