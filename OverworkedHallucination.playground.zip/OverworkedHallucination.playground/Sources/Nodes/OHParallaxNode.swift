import SpriteKit


class OHParallaxNode: OHNode {
    
    var row: Row
    
    var parallaxSize: ParallaxSize
    
    init(text: String, parallaxSize: ParallaxSize, speed: CGFloat, row: Row){
        
        self.row = row
        self.parallaxSize = parallaxSize
        
        // check the size that the text will take up
        let textNode = SKLabelNode(text: text)
        textNode.fontName = "SFMono-Regular"
        let size: CGSize
        
        switch parallaxSize {
        case .Small:
            textNode.fontSize = 5.0
            size = CGSize(width: textNode.frame.width+30, height: 9)
        case .Medium:
            textNode.fontSize = 10.0
            size = CGSize(width: textNode.frame.width+30, height: 14)
        case .Large:
            textNode.fontSize = 15.0
            size = CGSize(width: textNode.frame.width+30, height: 21)
        }
        
        let attributedTextNode = AttributedLabelNode(size: size)
        attributedTextNode.position = CGPoint(x: 0, y: 0)
        
        
        let attributedText = ColorParser().parse(text, fontSize: textNode.fontSize)
        attributedTextNode.attributedString = attributedText
        
        // call super
        super.init(texture: nil, color: .clear, size: size)
        self.zPosition = 1.0
        
        self.name = "Parallax"
        
        // add child texture node
        addChild(attributedTextNode)
        
        // add physics body
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        self.physicsBody?.isDynamic = false
        self.physicsBody?.affectedByGravity = false
        self.physicsBody?.allowsRotation = false
        self.physicsBody?.collisionBitMask = 0
        self.physicsBody?.categoryBitMask = platformCategory
        self.physicsBody?.contactTestBitMask = characterCategory
        
        // add action
        let moveDuration: Int //platforms is 14
        switch parallaxSize {
        case .Small:
            moveDuration = Int(60-speed)
            attributedTextNode.alpha = 0.25
        case .Medium:
            moveDuration = Int(45-speed)
            attributedTextNode.alpha = 0.5
        case .Large:
            moveDuration = Int(30-speed)
            attributedTextNode.alpha = 0.75
        }
        
        let moveAction = SKAction.moveBy(x: -3000, y: 0, duration: TimeInterval(moveDuration))
        self.run(moveAction)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

