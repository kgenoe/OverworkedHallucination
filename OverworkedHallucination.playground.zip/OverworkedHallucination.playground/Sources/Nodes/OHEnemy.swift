import SpriteKit
import UIKit

class OHEnemy: OHNode{
    
    var row: Row
    
    init(text: String, speed: CGFloat, row: Row){
        
        self.row = row
        
        // format text node
        let textNode = SKLabelNode(text: text)
        textNode.fontColor = UIColor.black
        textNode.fontName = "SFMono-Regular"
        textNode.fontSize = 20.0
        
        // format left (stop sign) component
        let leftTexture = SKTexture(imageNamed: "LeftError")
        let leftComponent = SKSpriteNode(texture: leftTexture)
        //leftComponent required ratio is: 1.78:1 (horiz:vert)
        leftComponent.size = CGSize(width: 54, height: 30)
        
        let size = CGSize(width: leftComponent.size.width+textNode.frame.width, height: 30)
        
        //set position of child nodes
        textNode.position = CGPoint(x: 0, y: -8)
        leftComponent.position = CGPoint(x: 0-size.width/2-leftComponent.size.width/2, y: 0)
        
        // call super
        let backgroundTexture = SKTexture(imageNamed: "RightError")
        super.init(texture: backgroundTexture, color: .clear, size: size)
        
        self.name = "Enemy"
        self.zPosition = 2.0

        
        // add child texture nodes
        addChild(leftComponent)
        addChild(textNode)
        
        // add physics body
        self.physicsBody = SKPhysicsBody(rectangleOf: self.size)
        self.physicsBody?.isDynamic = false
        self.physicsBody?.affectedByGravity = false
        self.physicsBody?.allowsRotation = false
        self.physicsBody?.usesPreciseCollisionDetection = true
        self.physicsBody?.categoryBitMask = enemyCategory
        self.physicsBody?.contactTestBitMask = physicsBody!.collisionBitMask
        
        // add action
        let moveDuration = 17-speed
        let moveAction = SKAction.moveBy(x: -3000, y: 0, duration: TimeInterval(moveDuration))
        self.run(moveAction)
    }
    
       required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

