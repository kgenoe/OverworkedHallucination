import SpriteKit
import UIKit


let BottomName = "Bottom"
let TopName = "Top"
let TopBarGreyName = "TopBarGrey"
let YellowBubbleName = "YellowBubble"
let RedBubbleName = "RedBubble"
let GreenBubbleName = "GreenBubble"
let MiddleBubbleName = "MiddleBubble"
let RightBubble1Name = "RightBubble1"
let RightBubble2Name = "RightBubble2"
let ScoreLabelName = "ScoreLabel"
let CharacterName = "Character"


class OHScene: SKScene {
    
    // Scene Properties
    var runVelocity: CGFloat!
    
    var jumpCount: Int!
    
    var platformFrequency: Int!
    
    var enemyFrequency: Int!
        
    var allowGravityFlip: Bool!
    
    var platforms: [String]!
    
    var isOver = false
    
    var score: Int = 0
    
    
    // Nodes
    var character: OHCharacter!
    
    fileprivate var top: SKSpriteNode!
    
    fileprivate var bottom: SKSpriteNode!
    
    fileprivate var scoreNode: SKLabelNode!
    
    
    //Node Factories
    var platformFactory: PlatformFactory!
    
    var coinFactory: CoinFactory!
    
    var parallaxFactory: ParallaxFactory!
    
    var enemyFactory: EnemyFactory!
    
    //Other
    var rowManager: RowManager!
    
    var parallaxRowManager: ParallaxRowManager!
    

    // Sounds
    var coinSoundAction: SKAction!
    
    var jumpSoundAction: SKAction!
    
    var flipSoundAction: SKAction!
    
    var gameOverSoundAction: SKAction!
    
    override func didMove(to view: SKView) {
        
        coinSoundAction = SKAction.playSoundFileNamed("coin.wav", waitForCompletion: false)
        jumpSoundAction = SKAction.playSoundFileNamed("jump.wav", waitForCompletion: false)
        flipSoundAction = SKAction.playSoundFileNamed("flip.wav", waitForCompletion: false)
        gameOverSoundAction = SKAction.playSoundFileNamed("gameOver.mp3", waitForCompletion: false)
        
        //calibrate parameters
        if runVelocity < 1 { runVelocity = 1 }
        if runVelocity > 10 { runVelocity = 10 }
        if jumpCount < 0 { jumpCount = 0 }
        if platformFrequency < 1 { platformFrequency = 1 }
        if platformFrequency > 10 { platformFrequency = 10 }
        if enemyFrequency < 1 { enemyFrequency = 1 }
        if enemyFrequency > 10 { enemyFrequency = 10 }
        if platforms == [] {
            platforms = defaultPlatforms
        }
        addDynamicPlatforms()

        physicsWorld.gravity = CGVector(dx: 0, dy: -6.0)
        
        rowManager = RowManager(scene: self)
        parallaxRowManager = ParallaxRowManager(scene: self)
        
        //set the physics world delegate
        self.physicsWorld.contactDelegate = self
        
        character = childNode(withName: CharacterName) as! OHCharacter
        character.availableJumps = self.jumpCount
        character.maxJumps = self.jumpCount
        
        bottom = childNode(withName: BottomName) as! SKSpriteNode
        bottom.physicsBody = SKPhysicsBody(rectangleOf: bottom.size)
        bottom.physicsBody?.isDynamic = false
        bottom.physicsBody?.affectedByGravity = false
        
        top = childNode(withName: TopName) as! SKSpriteNode
        top.physicsBody = SKPhysicsBody(rectangleOf: bottom.size)
        top.physicsBody?.isDynamic = false
        top.physicsBody?.affectedByGravity = false
        
        character.attachPhysicsBody()
        
        scoreNode = childNode(withName: ScoreLabelName) as! SKLabelNode
        scoreNode.text = "\(score)"
        let timerAction = SKAction.run {
            self.score += 1
            self.scoreNode.text = "\(self.score)"
        }
        
        let waitAction = SKAction.wait(forDuration: 0.05)
        let IncScore = SKAction.sequence([timerAction, waitAction])
        let repeatIncScore = SKAction.repeatForever(IncScore)
        run(repeatIncScore)
        
        
        platformFactory = PlatformFactory(scene: self, scrollSpeed: runVelocity, spawnFrequency: platformFrequency)
        platformFactory.start()
        
        coinFactory = CoinFactory(scene: self, scrollSpeed: runVelocity)
        coinFactory.start()
        
        parallaxFactory = ParallaxFactory(scene: self, scrollSpeed: runVelocity)
        parallaxFactory.start()
        
        enemyFactory = EnemyFactory(scene: self, scrollSpeed: runVelocity, spawnFrequency: enemyFrequency)
        enemyFactory.start()
    }
    
    func addDynamicPlatforms(){
        platforms.append("var runVelocity = \(runVelocity!)")
        platforms.append("var jumpCount = \(jumpCount!)")
        platforms.append("var platformFrequency = \(platformFrequency!)")
        platforms.append("var enemyFrequency = \(enemyFrequency!)")
        platforms.append("var allowGravityFlip = \(allowGravityFlip!)")

    }
    
    
    override func update(_ currentTime: TimeInterval) {
        
        if isOver { return }
        
        var isOnPlatform = false
        
        enumerateChildNodes(withName: "Platform") { (node, stop) in
            if let platformNode = node as? OHPlatform{
                // check if character is on the platform
                if platformNode.intersects(self.character){
                    isOnPlatform = true
                }
                // check if platform needs to be removed
                platformNode.checkForRemoval(boundary: 0-self.size.width/2)
            }
        }
        if !isOnPlatform {
            self.character.physicsBody!.affectedByGravity = true
        }
        
        enumerateChildNodes(withName: "Coin"){ (node, stop) in
            if let coinNode = node as? OHCoin{
                coinNode.checkForRemoval(boundary: 0-self.size.width/2)
            }
        }
        
        enumerateChildNodes(withName: "Enemy"){ (node, stop) in
            if let enemyNode = node as? OHEnemy{
                enemyNode.checkForRemoval(boundary: 0-self.size.width/2)
            }
        }
    }
    
    func gravityFlipped(_ sender: UIGestureRecognizer){
    
        if !isOver && allowGravityFlip{
            let reversedGravity = CGVector(dx: 0, dy: -1*self.physicsWorld.gravity.dy)
            
            enumerateChildNodes(withName: "Platform") { (node, stop) in
                if let platformNode = node as? OHPlatform{
                    platformNode.gravityFlipped(to: reversedGravity.dy)
                }
            }
            
            character.gravityFlipped(gravity: reversedGravity.dy)
            self.physicsWorld.gravity = reversedGravity
            
            run(flipSoundAction)
        }
    }
    
    func jump(_ sender: UITapGestureRecognizer){
        if character.availableJumps>0 && !isOver {
            let jump = CGVector(dx: 0, dy:self.physicsWorld.gravity.dy*(-2.5))
            character.physicsBody?.velocity = CGVector.zero
            character.physicsBody?.applyImpulse(jump)
            character.availableJumps = character.availableJumps-1
            
            run(jumpSoundAction)
        }
    }
    
    func endGame(){
        self.isOver = true
        
        for child in self.children{
            child.isPaused = true
        }
        
        removeAllActions()
        
        let darkColor = UIColor(colorLiteralRed: 0.1, green: 0.1, blue: 0.1, alpha: 0.75)
        let darkening = SKSpriteNode(color: darkColor, size: self.size)
        darkening.zPosition = 9
        darkening.alpha = 0.0
        addChild(darkening)
        
        let fadeInAction = SKAction.fadeIn(withDuration: 3.5)
        darkening.run(fadeInAction)
        
        character.isPaused = false
        self.physicsWorld.gravity = CGVector.zero
        character.isOver()
        
        
        let gameOverText = SKLabelNode(text: "Game Over")
        gameOverText.color = UIColor.white
        gameOverText.fontSize = 35
        gameOverText.fontName = "SFMono-Regular"
        gameOverText.position = CGPoint(x: 0, y: 30)
        gameOverText.xScale = 0.0
        gameOverText.yScale = 0.0
        gameOverText.zPosition = 10
        
        let ohView = view as! OverworkedHallucination
        ohView.jumpButton.alpha = 0.5
        ohView.flipButton.alpha = 0.5
        let scoreText = SKLabelNode(text: "Score: \(score)")

        scoreText.color = UIColor.white
        scoreText.fontSize = 35
        scoreText.fontName = "SFMono-Regular"
        scoreText.position = CGPoint(x: 0, y: -30)
        scoreText.xScale = 0.0
        scoreText.yScale = 0.0
        scoreText.zPosition = 10

        
        let continueText = SKLabelNode(text: "Reload playground or change parameters to play again!")
        continueText.fontSize = 15
        continueText.fontName = "SFMono-Regular"
        continueText.position = CGPoint(x: 0, y: -100)
        continueText.xScale = 0.0
        continueText.yScale = 0.0
        continueText.zPosition = 10
        
        let growIn = SKAction.scaleX(to: 1.2, y: 1.3, duration: 0.45)
        let shrinkDown = SKAction.scaleX(to: 1.0, y:1.0, duration: 0.10)
        let wait = SKAction.wait(forDuration: 0.3)
        
        addChild(gameOverText)
        addChild(scoreText)
        addChild(continueText)
        
        let bottom = (0-self.size.height/2)+49+character.size.height
        let characterFall = SKAction.moveTo(y: bottom, duration: 3.5)
        character.run(characterFall, completion: {
            gameOverText.run(SKAction.sequence([growIn,shrinkDown]))
            scoreText.run(SKAction.sequence([wait, growIn, shrinkDown]))
            continueText.run(SKAction.sequence([wait, wait, growIn, shrinkDown]))
        })
        
        run(gameOverSoundAction)
    }

}

extension OHScene: SKPhysicsContactDelegate{
    func didBegin(_ contact: SKPhysicsContact) {
        
        if isOver { return }
        
        let otherNode = contact.bodyA.node != character ?
                                contact.bodyA.node :
                                contact.bodyB.node
        
        // potentially running on platform
        if let platformNode = otherNode as? OHPlatform{
            platformNode.collisionWith(player: character)
        }
        
        //running on floor
        if otherNode == top && self.physicsWorld.gravity.dy > 0 {
            character.physicsBody!.affectedByGravity = true
            character.availableJumps = character.maxJumps
        }
        
        //running on ceiling
        if otherNode == bottom && self.physicsWorld.gravity.dy < 0{
            character.physicsBody!.affectedByGravity = true
            character.availableJumps = character.maxJumps
        }
        
        if let coinNode = otherNode as? OHCoin{
            coinNode.collisionWith(player: character)
            score += 100
            self.scoreNode.text = "\(self.score)"

            self.run(self.coinSoundAction)
        }
        
        if let _ = otherNode as? OHEnemy{
            endGame()
        }
    }
}
