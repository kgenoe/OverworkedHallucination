import UIKit
import SpriteKit

public class OverworkedHallucination: SKView {

    
    //MARK: User Adjustable Parameters
    public var runningSpeed: Int = 5
    
    public var numberOfJumps: Int = 3
    
    public var platformFrequency: Int = 5
    
    public var enemyFrequency: Int = 5
        
    public var allowGravityFlip: Bool = true
    
    public var platforms: [String] = ["          "]
    
    
    private var gameScene: OHScene

    var jumpButton: UIButton!
    
    var flipButton: UIButton!
    
    public init() {
        
        gameScene = OHScene(fileNamed: "OHScene")!
        

        super.init(frame: CGRect(x: 0, y: 0, width: 750, height: 500))

        self.loadFont()
    }
    
    public func start(){
        
        gameScene.runVelocity = CGFloat(runningSpeed)
        gameScene.jumpCount = numberOfJumps
        gameScene.platformFrequency = platformFrequency
        gameScene.enemyFrequency = enemyFrequency
        gameScene.allowGravityFlip = allowGravityFlip
        gameScene.platforms = platforms
        
        self.addGestureGecognizers()
        
        let backgroundView = UIView(frame: CGRect(x: 0, y: 450, width: 750, height: 100))
        backgroundView.backgroundColor = UIColor.black
        self.addSubview(backgroundView)

        
        jumpButton = UIButton(frame: CGRect(x: (750/2)-100, y: 460, width: 75, height: 30))
        jumpButton.layer.borderColor = UIColor.white.cgColor
        jumpButton.layer.borderWidth = 1.0
        jumpButton.layer.cornerRadius = 5.0
        jumpButton.setTitle("Jump", for: [])
        jumpButton.addTarget(gameScene, action: #selector(gameScene.jump(_:)), for: .touchUpInside)
        self.addSubview(jumpButton)

        flipButton = UIButton(frame: CGRect(x: (750/2)+100, y: 460, width: 75, height: 30))
        flipButton.layer.borderColor = UIColor.white.cgColor
        flipButton.layer.borderWidth = 1.0
        flipButton.layer.cornerRadius = 5.0
        flipButton.setTitle("Flip", for: [])
        flipButton.addTarget(gameScene, action: #selector(gameScene.gravityFlipped(_:)), for: .touchUpInside)
        self.addSubview(flipButton)
        
        self.presentScene(gameScene)
    }
    
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func loadFont(){
        let cfURL = Bundle.main.url(forResource: "SFMono-Regular", withExtension: ".otf")!
        CTFontManagerRegisterFontsForURL(cfURL as CFURL, CTFontManagerScope.process, nil)
        
    }
    
    func addGestureGecognizers(){
        let swipeGestureRecognizer = UISwipeGestureRecognizer(target: gameScene, action: #selector(gameScene.gravityFlipped(_:)))
        swipeGestureRecognizer.delegate = self
        self.addGestureRecognizer(swipeGestureRecognizer)
        
        //add tap gesture
        let tapGestureRecognizer = UITapGestureRecognizer(target: gameScene, action: #selector(gameScene.jump(_:)) )
        tapGestureRecognizer.delegate = self
        self.addGestureRecognizer(tapGestureRecognizer)
    }
    
    
  
}

extension OverworkedHallucination: UIGestureRecognizerDelegate{
    public func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
}
