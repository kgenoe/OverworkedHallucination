import UIKit
import SpriteKit

struct ParallaxFactory {
    
    private var scene: OHScene
    
    private var scrollSpeed: CGFloat
    
    init(scene: OHScene, scrollSpeed: CGFloat) {
        self.scene = scene
        self.scrollSpeed = scrollSpeed
    }
    
    func start(){
        
        let waitTime = 0.5 //(frequency is between 1-10, making wait time between 10-1 seconds
        let wait = SKAction.wait(forDuration: waitTime)
        let spawn = SKAction.run {
            
            //randomly select a text string
            let rand = Int(arc4random_uniform(UInt32(self.scene.platforms.count)))
            let text = self.scene.platforms[rand]
            
            let availableRows = self.scene.parallaxRowManager.availableRows()
            if availableRows.count > 0 {
                let row = Row.selectRandomRowFrom(availableRows)
                let parallaxSize = ParallaxSize.selectRandomSize()
                
                let parallaxNode = OHParallaxNode(text: text, parallaxSize: parallaxSize, speed: self.scrollSpeed, row: row)
                parallaxNode.position = CGPoint(x: self.scene.frame.maxX+parallaxNode.size.width/2, y: row.rawValue)
                
                self.scene.addChild(parallaxNode)

            }
        }
        scene.run(SKAction.repeatForever(SKAction.sequence([wait, spawn])))
    }
}

