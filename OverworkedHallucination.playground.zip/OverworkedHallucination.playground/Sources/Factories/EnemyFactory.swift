import UIKit
import SpriteKit

struct EnemyFactory {
    
    private var scene: OHScene
    
    private var scrollSpeed: CGFloat
    
    private var frequency: Double
    
    init(scene: OHScene, scrollSpeed: CGFloat, spawnFrequency: Int) {
        self.scene = scene
        self.scrollSpeed = scrollSpeed
        self.frequency = Double(spawnFrequency)
    }
    
    let errors = ["segmentation fault: 11",
                  "Missing semicolon",
                  "Error!",
                  "fatal error",
                  "Optional not unwrapped"]
    
    func start(){
        
        let waitTime = 10.0/frequency //(frequency is between 1-10, making wait time between 8-0.8 seconds
        let wait = SKAction.wait(forDuration: waitTime)
        let spawn = SKAction.run {
            //randomly select a text string
            let rand = Int(arc4random_uniform(UInt32(self.errors.count)))
            let enemyText = self.errors[rand]
            
            let availableRows = self.scene.rowManager.availableRows()
            if availableRows.count > 0 {
                let row = Row.selectRandomRowFrom(availableRows)
                let enemy = OHEnemy(text: enemyText, speed: self.scrollSpeed, row: row)
                enemy.position = CGPoint(x: self.scene.frame.maxX+enemy.size.width, y: row.rawValue)
                self.scene.addChild(enemy)
            }
        }
        scene.run(SKAction.repeatForever(SKAction.sequence([wait, spawn])))
    }
}
