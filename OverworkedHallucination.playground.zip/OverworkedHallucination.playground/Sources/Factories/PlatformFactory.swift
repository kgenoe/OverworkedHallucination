import UIKit
import SpriteKit

struct PlatformFactory {
    
    private var scene: OHScene
    
    private var scrollSpeed: CGFloat
    
    private var frequency: Double
    
    init(scene: OHScene, scrollSpeed: CGFloat, spawnFrequency: Int) {
        self.scene = scene
        self.scrollSpeed = scrollSpeed
        self.frequency = Double(spawnFrequency)
    }
    
    
    func start(){
        
        let waitTime = 7.0/frequency //(frequency is between 1-10, making wait time between 10-1 seconds
        let wait = SKAction.wait(forDuration: waitTime)
        let spawn = SKAction.run {
            //randomly select a text string
            let rand = Int(arc4random_uniform(UInt32(self.scene.platforms.count)))
            let platformText = self.scene.platforms[rand]
            
            let availableRows = self.scene.rowManager.availableRows()
            if availableRows.count > 0 {
                let row = Row.selectRandomRowFrom(availableRows)
                let platform = OHPlatform(text: platformText, speed: self.scrollSpeed, row: row)
                platform.position = CGPoint(x: self.scene.frame.maxX+platform.size.width/2, y: row.rawValue)
                platform.gravity = self.scene.physicsWorld.gravity.dy
                self.scene.addChild(platform)
            }
        }
        scene.run(SKAction.repeatForever(SKAction.sequence([wait, spawn])))
    }
}
