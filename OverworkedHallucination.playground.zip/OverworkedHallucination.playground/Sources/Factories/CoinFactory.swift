import UIKit
import SpriteKit

struct CoinFactory {
    
    private var scene: OHScene
    
    private var scrollSpeed: CGFloat
    
    init(scene: OHScene, scrollSpeed: CGFloat) {
        self.scene = scene
        self.scrollSpeed = scrollSpeed
    }
    
    
    func start(){
        let spawn = SKAction.run {
            let availableRows = self.scene.rowManager.availableRows()
            if availableRows.count > 0 {
                let row = Row.selectRandomRowFrom(availableRows)

                for i in 0...7{
                    let rand = Int(arc4random_uniform(2))
                    let coinText = "\(rand)"
            
                    let coin = OHCoin(text: coinText, speed: self.scrollSpeed, row: row)
                    let xOffset = CGFloat(i) * coin.size.width
                    coin.position = CGPoint(x: self.scene.frame.maxX+coin.size.width/2+xOffset, y: row.rawValue)
                    self.scene.addChild(coin)
                }
            }
        }
        
        let waitTime = 2.681
        let wait = SKAction.wait(forDuration: waitTime)
        scene.run(SKAction.repeatForever(SKAction.sequence([wait, spawn])))
    }
}
