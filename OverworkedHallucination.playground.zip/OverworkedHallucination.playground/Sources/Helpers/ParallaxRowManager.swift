import Foundation
import SpriteKit

class ParallaxRowManager: NSObject {
    
    var scene: OHScene
    
    init(scene: OHScene) {
        self.scene =  scene
    }
    
    func availableRows() -> [Row]{
        
        var availableRows:[Row] = [.One, .Two, .Three, .Four, .Five, .Six, .Seven, .Eight]
        
        scene.enumerateChildNodes(withName: "Parallax") { (node, stop) in
            if let parallaxNode = node as? OHParallaxNode{
                if parallaxNode.frame.maxX > self.scene.size.width/2 {
                    if let index = availableRows.index(of: parallaxNode.row){
                        availableRows.remove(at: index)
                    }
                }
            }
        }
        return availableRows
    }
}
