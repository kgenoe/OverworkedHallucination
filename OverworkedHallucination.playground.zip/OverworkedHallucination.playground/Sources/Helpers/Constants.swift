import Foundation
import SpriteKit

let runKey = "running"

let jumpKey = "jumping"

let viewSize = CGSize(width: 750, height: 400)

let characterCategory: UInt32 = 1
let platformCategory: UInt32 = 2
let enemyCategory: UInt32 = 3
let boundaryCategory: UInt32 = 4
let coinCategory: UInt32 = 6

enum Row: CGFloat{
    // Range: 152 to - 182
    // start at 1/2 height of an error (30/2 = 15)
    // each row is 41.75 apart
    // add offset of 6 at begining to center rows between top and bottom
    
    case One = 131
    case Two = 89.25
    case Three = 47.5
    case Four = 5.75
    case Five = -36
    case Six = -77.75
    case Seven = -119.5
    case Eight = -161.25
    
    static func selectRandomRow() -> Row {
        let rand = Int(arc4random_uniform(8))
        if rand == 0{ return .One }
        else if rand == 1{ return .Two }
        else if rand == 2{ return .Three }
        else if rand == 3{ return .Four }
        else if rand == 4{ return .Five }
        else if rand == 5{ return .Six }
        else if rand == 6{ return .Seven }
        else { return .Eight }
    }
    
    static func selectRandomRowFrom(_ rows: [Row]) -> Row{
        let rand = Int(arc4random_uniform(UInt32(rows.count)))
        return rows[rand]
    }
}

enum ParallaxSize{
    case Small
    case Medium
    case Large
    
    static func selectRandomSize() -> ParallaxSize{
        let rand = Int(arc4random_uniform(3))
        if rand == 0 { return .Small }
        else if rand == 1 { return .Medium }
        else { return .Large }
    }
}

var defaultPlatforms = [
    "import SceneKit",
    "let powerLevel = 9001",
    "let wwdc = \"going\"",
    "self.location = CLLocation(latitude: 37.328611, longitude: -121.888889)",
    "let status = \"student\"",
    "let project = \"OverworkedHalucination.playground\"",
    "var cupsOfCoffeePerDay = 5",
    "OHScene().start()",
    "let xcodeTheme = \"Dusk\""
]
