import Foundation
import UIKit

struct ColorParser {
    
    static var keywordColor = UIColor(colorLiteralRed: 215/255.0, green: 0/255.0, blue: 143/255.0, alpha: 1.0)
    
    static var digitColor = UIColor(colorLiteralRed: 20/255.0, green: 156/255.0, blue: 146/255.0, alpha: 1.0)
    
    static var stringColor = UIColor(colorLiteralRed: 211/255.0, green: 35/255.0, blue: 46/255.0, alpha: 1.0)
    
    static var commentColor = UIColor(colorLiteralRed: 69/255.0, green: 187/255.0, blue: 62/255.0, alpha: 1.0)
    
    static var customItemColor = UIColor(colorLiteralRed: 29/255.0, green: 169/255.0, blue: 162/255.0, alpha: 1.0)
    
    static var otherItemColor = UIColor(colorLiteralRed: 37/255.0, green: 144/255.0, blue: 141/255.0, alpha: 1.0)
    
    static var defaultColor = UIColor(colorLiteralRed: 221/255.0, green: 223/255.0, blue: 228/255.0, alpha: 1.0)
    
    static var preprocessorColor = UIColor(colorLiteralRed: 199/255.0, green: 122/255.0, blue: 75/255.0, alpha: 1.0)
    
    static var urlColor = UIColor(colorLiteralRed: 81/255.0, green: 36/255.0, blue: 227/255.0, alpha: 1.0)
    
    
    let customItems = ["OHCharacter", "OHEnemy", "OHNode", "OHPlatform", "OHCoin", "RowManager", "Constants", "ColorParser", "start", "parallaxFactory", "Pokemon", "LiverpoolFC", "winTheLeague", "removeFromParent", "zPosition", "attributedText", "CGSize"]
    
    let otherItems = ["print"]
    
    let symbols = "!@#$%^&*()_+=-{}]\\\"'[]{}/,.>< "
    
    let keywords = ["Any","associativity", "break", "case", "catch", "class", "continue", "convenience", "default", "deinit", "didSet", "do", "else", "enum", "extension", "fallthrough", "false", "final", "for", "func", "get", "guard", "if", "import", "in", "infix", "init", "inout", "internal", "lazy", "let", "mutating", "nil", "operator", "override", "postfix", "precedence", "prefix", "private", "public", "repeat", "required", "return", "self", "set", "static", "struct", "subscript", "super", "switch", "throws", "true", "try", "var", "weak", "where", "while", "willSet", "abs", "max", "min", "@IBOutlet", "@IBAction"]
    
    let types = ["Array", "Bool", "Dictionary", "Error", "Int", "Set", "String", "Tuple", "Date"]
    
    
    func parse(_ text: String, fontSize: CGFloat = 20.0) -> NSMutableAttributedString{
        
        var attributedText = NSMutableAttributedString(string: text)
        
        //add font and size
        
        
        attributedText = styleFontFor(attributedText: attributedText, fontSize: fontSize)
        
        attributedText = styleDefaultFor(attributedText: attributedText)
        attributedText = styleNumbersFor(attributedText: attributedText)
        attributedText = styleKeywordsFor(attributedText: attributedText)
        attributedText = styleTypesFor(attributedText: attributedText)
        attributedText = styleOtherItemsFor(attributedText: attributedText)
        attributedText = styleCustomItemsFor(attributedText: attributedText)
        attributedText = styleCommentsFor(attributedText: attributedText)
        attributedText = styleStringsFor(attributedText: attributedText)
        attributedText = styleURLsFor(attributedText: attributedText)
        
        return attributedText
    }
    
    private func styleFontFor(attributedText: NSMutableAttributedString, fontSize: CGFloat) -> NSMutableAttributedString {
        let font = UIFont(name: "SFMono-Regular", size: fontSize)
        let fullRange = NSMakeRange(0, attributedText.length)
        attributedText.addAttribute(NSFontAttributeName, value: font!, range: fullRange)
        return attributedText
    }
    
    private func styleDefaultFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString{
        let defaultAttributes = [NSForegroundColorAttributeName: ColorParser.defaultColor]
        let fullRange = NSMakeRange(0, attributedText.length)
        attributedText.addAttributes(defaultAttributes, range: fullRange)
        return attributedText
    }
    
    private func styleKeywordsFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString{
        let text = attributedText.string
        var keywordRanges: [NSRange] = []
        
        // get ranges of any instance of a keyword in text
        for keyword in keywords {
            let ranges: [NSRange]
            
            do {
                // find the ranges of all instances of "keyword" in text
                let regex = try NSRegularExpression(pattern: keyword, options: [])
                ranges = regex.matches(in: text, options: [], range: NSMakeRange(0, text.characters.count)).map{ $0.range }
            }
            catch{ ranges = [] }
            keywordRanges += ranges
        }
        
        
        let keywordAttributes = [NSForegroundColorAttributeName: ColorParser.keywordColor]
        for range in keywordRanges {
            
            let beforeChar: Character
            let afterChar: Character
            
            if range.location-1>=0{
                let beforeRangeIndex = text.index(text.startIndex, offsetBy: range.location-1)
                beforeChar = text.characters[beforeRangeIndex]
            }else {
                beforeChar = " "
            }
            
            if range.location+range.length < text.characters.count {
                let afterRangeIndex = text.index(text.startIndex, offsetBy: range.location+range.length)
                afterChar = text.characters[afterRangeIndex]
            }
            else{
                afterChar = " "
            }
            
            if symbols.characters.contains(beforeChar) && symbols.characters.contains(afterChar){
                attributedText.addAttributes(keywordAttributes, range: range)
            }
        }
        
        return attributedText
    }
    
    private func styleTypesFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString {
        let text = attributedText.string
        var itemRanges: [NSRange] = []
        
        for item in types {
            let ranges: [NSRange]
            
            do {
                // find the ranges of all instances of "item" in text
                let regex = try NSRegularExpression(pattern: item, options: [])
                ranges = regex.matches(in: text, options: [], range: NSMakeRange(0, text.characters.count)).map{ $0.range }
            }
            catch{ ranges = [] }
            itemRanges += ranges
        }
        
        let typeItemAttributes = [NSForegroundColorAttributeName: ColorParser.otherItemColor]
        for range in itemRanges {
            attributedText.addAttributes(typeItemAttributes, range: range)
        }
        
        return attributedText
    }
    
    private func styleNumbersFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString{
        let text = attributedText.string
        
        var digitRanges: [NSRange] = []
        
        let chars = text.characters
        for i in chars.indices[text.startIndex..<text.endIndex] {
            
            let char = chars[i]
            let unicodeString = String(char).unicodeScalars
            let unicodeChar = unicodeString[unicodeString.startIndex]
            let digits = NSCharacterSet.decimalDigits as NSCharacterSet
            let charIsADigit = digits.longCharacterIsMember(unicodeChar.value)
            
            if charIsADigit {
                let position = chars.distance(from: chars.startIndex, to: i)
                let range = NSMakeRange(position, 1)
                digitRanges.append(range)
            }
        }
        
        let digitAttributes = [NSForegroundColorAttributeName: ColorParser.digitColor]
        
        for range in digitRanges {
            attributedText.addAttributes(digitAttributes, range: range)
        }
        
        return attributedText
    }
    
    private func styleCustomItemsFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString {
        
        let text = attributedText.string
        var itemRanges: [NSRange] = []
        
        // get ranges of any instance of a custom item (class/func) in text
        for item in customItems {
            let ranges: [NSRange]
            
            do {
                // find the ranges of all instances of "item" in text
                let regex = try NSRegularExpression(pattern: item, options: [])
                ranges = regex.matches(in: text, options: [], range: NSMakeRange(0, text.characters.count)).map{ $0.range }
            }
            catch{ ranges = [] }
            itemRanges += ranges
        }
        
        
        let customItemAttributes = [NSForegroundColorAttributeName: ColorParser.customItemColor]
        for range in itemRanges {
            attributedText.addAttributes(customItemAttributes, range: range)
        }
        
        return attributedText
    }
    
    private func styleOtherItemsFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString {
        let text = attributedText.string
        var itemRanges: [NSRange] = []
        
        // get ranges of any instance of a other item (class/func) in text
        for item in otherItems {
            let ranges: [NSRange]
            
            do {
                // find the ranges of all instances of "item" in text
                let regex = try NSRegularExpression(pattern: item, options: [])
                ranges = regex.matches(in: text, options: [], range: NSMakeRange(0, text.characters.count)).map{ $0.range }
            }
            catch{ ranges = [] }
            itemRanges += ranges
        }
        
        
        let otherItemAttributes = [NSForegroundColorAttributeName: ColorParser.otherItemColor]
        for range in itemRanges {
            attributedText.addAttributes(otherItemAttributes, range: range)
        }
        
        return attributedText
    }
    
    private func styleStringsFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString{
        let text = attributedText.string
        if text.components(separatedBy: "\"").count == 3 {
            let stringComponent = text.components(separatedBy: "\"")[1]
            let stringRange = text.range(of: stringComponent)!
            let stringStartPos = text.distance(from: text.startIndex, to: stringRange.lowerBound)
            let stringEndPos = text.distance(from: text.startIndex, to: stringRange.upperBound)
            let stringNSRange = NSMakeRange(stringStartPos-1, (stringEndPos-stringStartPos)+2)
            
            let stringAttributes = [NSForegroundColorAttributeName: ColorParser.stringColor]
            attributedText.addAttributes(stringAttributes, range: stringNSRange)
        }
        return attributedText
    }
    
    private func styleCommentsFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString{
        let text = attributedText.string
        
        var commentRanges: [NSRange] = [ ]
        
        // add /* */ comment ranges
        if text.contains("/*") && text.contains("*/"){
            let commentStartIndex = text.range(of: "/*")!.lowerBound
            let commentEndIndex = text.range(of: "*/")!.upperBound
            let commentStartPos = text.distance(from: text.startIndex, to: commentStartIndex)
            let commentEndPos = text.distance(from: text.startIndex, to: commentEndIndex)
            let commentRange = NSMakeRange(commentStartPos, commentEndPos-commentStartPos)
            commentRanges.append(commentRange)
        }
        
        // add // comment ranges
        if text.contains("//") {
            let commentStartIndex = text.range(of: "//")!.lowerBound
            let commentStartPos = text.distance(from: text.startIndex, to: commentStartIndex)
            let commentEndPos = text.distance(from: text.startIndex, to: text.endIndex)
            let commentRange = NSMakeRange(commentStartPos, commentEndPos-commentStartPos)
            commentRanges.append(commentRange)
        }
        
        let commentAttributes = [NSForegroundColorAttributeName: ColorParser.commentColor]
        for commentRange in commentRanges{
            attributedText.addAttributes(commentAttributes, range: commentRange)
        }
        
        return attributedText
    }
    
    private func styleURLsFor(attributedText: NSMutableAttributedString) -> NSMutableAttributedString {
        let text = attributedText.string
        let urlAttributes = [NSForegroundColorAttributeName: ColorParser.urlColor]
        
        
        if text.contains("https://"){
            let urlStartIndex = text.range(of: "https://")!.lowerBound
            let startPos = text.distance(from: text.startIndex, to: urlStartIndex)
            let length = text.distance(from: urlStartIndex, to: text.endIndex)
            let urlRange = NSMakeRange(startPos, length)
            attributedText.addAttributes(urlAttributes, range: urlRange)
        }
        
        if text.contains("http://"){
            let urlStartIndex = text.range(of: "http://")!.lowerBound
            let startPos = text.distance(from: text.startIndex, to: urlStartIndex)
            let length = text.distance(from: urlStartIndex, to: text.endIndex)
            let urlRange = NSMakeRange(startPos, length)
            attributedText.addAttributes(urlAttributes, range: urlRange)
        }
        return attributedText
    }
}
