import Foundation
import SpriteKit

class RowManager: NSObject {
    
    var scene: OHScene
    
    
    init(scene: OHScene) {
        self.scene = scene
    }

    
    func availableRows() -> [Row]{
        
        var availableRows:[Row] = [.One, .Two, .Three, .Four, .Five, .Six, .Seven, .Eight]
        
        scene.enumerateChildNodes(withName: "Platform") { (node, stop) in
            if let platformNode = node as? OHPlatform{
                if platformNode.frame.maxX > self.scene.size.width/2 {
                    if let index = availableRows.index(of: platformNode.row){
                        availableRows.remove(at: index)
                    }
                }
            }
        }
        
        scene.enumerateChildNodes(withName: "Coin") { (node, stop) in
            if let coinNode = node as? OHCoin{
                if coinNode.frame.maxX > self.scene.size.width/2 {
                    if let index = availableRows.index(of: coinNode.row){
                        availableRows.remove(at: index)
                    }
                }
            }
        }
        
        scene.enumerateChildNodes(withName: "Enemy") { (node, stop) in
            if let enemyNode = node as? OHEnemy{
                if enemyNode.frame.maxX > self.scene.size.width/2 {
                    if let index = availableRows.index(of: enemyNode.row){
                        availableRows.remove(at: index)
                    }
                }
            }
        }
        
        return availableRows
    }
}
