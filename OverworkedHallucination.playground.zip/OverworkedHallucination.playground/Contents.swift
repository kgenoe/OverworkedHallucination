import PlaygroundSupport

//: # Overworked Hallucination
/*:

 ![8bit girl posing](GirlFall.png)
 */
//: ### This is Erica!

/*: She's been working ***way*** to hard on her 2017 WWDC Student Scholarship application. After a few too many cups of coffee, she fell asleep at her desk and awoke to find herself inside her computer!*/
let dream = OverworkedHallucination()
/*: What else is there to do now but run! Help Erica set a high score by jumping on **lines of code**, avoiding **errors**, and collecting **1's and 0's**. Tap to jump and swipe to flip gravity, or use the labeled buttons at the bottom of the screen. */
//: ### Customize Erica
//: Number of times Erica can jump before needing to touch the ground or another platform
dream.numberOfJumps = 3

//: How fast Erica will run. Values can range between 1 and 10, 1 being the slowest and 10 being the fastest!
dream.runningSpeed = 5

//: Can Erica flip gravity? If true swipe in any direction and Erica will flip upside down.
dream.allowGravityFlip = true

//: ### Customize Computer
//: How frequently errors will plague Erica's coding run! Values can range between 1 and 10, 1 being the least and 10 being the most.
dream.enemyFrequency = 2

//: How frequently platforms will appear for Erica to jump on.  Values can range between 1 and 10, 1 being the least and 10 being the most.
dream.platformFrequency = 5

//: The lines of code that will be used as platforms in the game.
dream.platforms = [
    "import SceneKit",
    "let powerLevel = 9001",
    "let wwdc = \"going\"",
    "self.location = CLLocation(latitude: 37.328611, longitude: -121.888889)",
    "let status = \"student\"",
    "let project = \"OverworkedHallucination.playground\"",
    "var cupsOfCoffeePerDay = 5",
    "OHScene().start()",
    "let xcodeTheme = \"Dusk\"",
    "parallaxFactory.start()",
    "let addiction = \"running\"",
    "let loadBestGame = Pokemon()",
    "let home = \"Sault Ste. Marie\"",
    "LiverpoolFC.winTheLeague()",
    "let coinNode = node as? OHCoin",
    "@IBOutlet weak var scoreLabel: UILabel!",
    "let mid = self.size.width/2",
    "let devTools = [xcode, terminal, instruments]",
    "// youre doing great!",
    "// keep going!",
    "// swipe to flip gravity",
    "// tap to jump",
    "let hoursSpentOnThis = 80",
    "let viewSize = CGSize(width: 750, height: 400)",
    "return attributedText",
    "self.scene = scene",
    "character.zPosition = 10",
    "self.removeFromParent()"
    ]


dream.start()
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = dream
